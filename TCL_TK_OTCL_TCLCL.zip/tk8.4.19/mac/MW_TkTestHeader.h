#if __POWERPC__
#include "MW_TkTestHeaderPPC"
#elif __CFM68K__
#include "MW_TkTestHeaderCFM68K"
#else
#include "MW_TkTestHeader68K"
#endif
